# Module 4 project – Movie organizer.

Starter for Module 4 project in Algoritmika Coding Bootcamp

## How to run

```
npm install
npm start
```
